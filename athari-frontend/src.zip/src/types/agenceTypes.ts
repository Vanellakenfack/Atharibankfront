export interface Agence {
  id: number;
  code: string;
  name: string;        
  shortName: string;  
  createdAt: string;
  updatedAt: string;   
}