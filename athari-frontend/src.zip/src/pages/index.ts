// Export des pages
export { default as FraisCommissionPage } from './FraisCommissionPage';
export { default as FraisApplicationPage } from './FraisApplicationPage';
export { default as MataManagementPage } from './MataManagementPage';
